# aplicativo
aplicativo sobre a contratação de terceirizado
temos que fazer as telas principais em html